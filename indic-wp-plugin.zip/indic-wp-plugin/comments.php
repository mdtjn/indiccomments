<div id = "indicComment-master">
	<div id="fb-root"></div>
	
		<script>
			var page_uid = document.URL;
			(function() {
				var dsq = document.createElement('script'); dsq.type = 'text/javascript'; dsq.async = true;
				dsq.src = 'https://indiccomments.youngsoch.in/assets/js/indic.js';
				(document.getElementsByTagName('head')[0] || document.getElementsByTagName('body')[0]).appendChild(dsq);
			})();
			
		</script>
	<div id="indicComment"></div>	
  </div>